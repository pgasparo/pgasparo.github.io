# Publications

<a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ" class="publication-link" target="_blank">View full profile on Google Scholar ↗</a>

## 2026

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1016/j.modpat.2026.100960" class="publication-link">
                Spatial Molecular Plasticity Underpins Lethal Morphologies in Lung Adenocarcinoma
            </a>
        </h3>
        <div class="publication-venue"><em>Modern Pathology</em>, 100960</div>
        <div class="publication-authors">HL Williams, N Poulain, I Powley, <strong>S Martinelli</strong>, R Bielik, H Leslie, C Nixon, ...</div>
        <div class="publication-curiosity">🔬 Lung cancer is not one disease — its deadliest forms hide in shape-shifting molecular landscapes.</div>
        <div class="publication-description">Spatial molecular analysis revealing how molecular plasticity underlies the lethal morphological patterns in lung adenocarcinoma.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1101/2026.02.06.704414" class="publication-link">
                Morphospatial Profiling of Cancer-Associated Fibroblasts Reveals Architectural Subtypes of Pancreatic Ductal Adenocarcinoma
            </a>
        </h3>
        <div class="publication-venue"><em>bioRxiv</em> preprint</div>
        <div class="publication-authors">AS Bryce, <strong>S Martinelli</strong>, L Schubert Santana, L Officer-Jones, RL Baird, ...</div>
        <div class="publication-curiosity">🏗️ Tumors don't act alone — their fibroblast scaffolding reveals hidden architectural blueprints.</div>
        <div class="publication-description">Morphospatial profiling of cancer-associated fibroblasts uncovers distinct architectural subtypes in pancreatic ductal adenocarcinoma.</div>
    </div>
</div>

## 2025

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1101/2025.06.24.25328454" class="publication-link">
                Assessing the Mental Health Crisis Among New York's Postdoctoral Researchers
            </a>
        </h3>
        <div class="publication-venue"><em>medRxiv</em> preprint</div>
        <div class="publication-authors"><strong>S Martinelli</strong>, J Uddin, EB Alonso, R Doreste, S Jalal</div>
        <div class="publication-curiosity">🧠 The people who advance science often struggle the most with the system built around it.</div>
        <div class="publication-description">Survey-based assessment of the mental health crisis affecting postdoctoral researchers in New York, highlighting systemic challenges in academic research environments.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1101/2025.10.16.682563" class="publication-link">
                Exploring the Utility of Self-Supervised Learning in the Analysis of Multiplex Immunofluorescence Lung Adenocarcinoma Images
            </a>
        </h3>
        <div class="publication-venue"><em>Journal of Pathology</em> <strong>267</strong></div>
        <div class="publication-authors">SS Szalma, KR Rakovic, LF Farndale, <strong>S Martinelli</strong>, LOJ Jones, KY Yuan, ...</div>
        <div class="publication-curiosity">🤖 Teaching AI to see cancer without telling it what cancer looks like.</div>
        <div class="publication-description">Evaluating how self-supervised learning approaches can improve the analysis of multiplex immunofluorescence images in lung adenocarcinoma.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1016/j.biopsych.2025.02.632" class="publication-link">
                Behavioral Characterization of OCD-Related Phenotypes in Mice With Differential Slitrk5 Deficiencies
            </a>
        </h3>
        <div class="publication-venue"><em>Biological Psychiatry</em> <strong>97</strong>(9), S259</div>
        <div class="publication-authors">B Bai, <strong>S Martinelli</strong>, M Lutolf, M Šabanobić, J Kim, F Lee</div>
        <div class="publication-curiosity">🐭 OCD isn't just about habits — a single gene can shift the balance between order and compulsion.</div>
        <div class="publication-description">Behavioral characterization of OCD-related phenotypes in mouse models with differential Slitrk5 deficiencies, informing translational understanding of obsessive-compulsive disorder.</div>
    </div>
</div>

## 2024

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1038/s41467-024-46953-x" class="publication-link">
                SKA2 Regulated Hyperactive Secretory Autophagy Drives Neuroinflammation-Induced Neurodegeneration
            </a>
        </h3>
        <div class="publication-venue"><em>Nature Communications</em> <strong>15</strong>(1), 2635</div>
        <div class="publication-authors">J Hartmann, T Bajaj, J Otten, C Klengel, T Ebert, AK Gellner, E Junglas, ...</div>
        <div class="publication-curiosity">♻️ When the brain's recycling system goes into overdrive, it can destroy what it was meant to protect.</div>
        <div class="publication-description">Demonstrates how SKA2-regulated hyperactive secretory autophagy drives neuroinflammation-induced neurodegeneration, revealing a novel mechanistic pathway.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1126/scisignal.adj6603" class="publication-link">
                Inhibiting Hippo Pathway Kinases Releases WWC1 to Promote AMPAR-Dependent Synaptic Plasticity and Long-Term Memory in Mice
            </a>
        </h3>
        <div class="publication-venue"><em>Science Signaling</em> <strong>17</strong>(834), eadj6603</div>
        <div class="publication-authors">J Stepan, DE Heinz, F Dethloff, S Wiechmann, <strong>S Martinelli</strong>, K Hafner, ...</div>
        <div class="publication-curiosity">� The Hippo pathway — named for the overgrowth it causes — also holds the key to how memories stick.</div>
        <div class="publication-description">Shows that inhibiting Hippo pathway kinases releases WWC1 to promote AMPA receptor-dependent synaptic plasticity and long-term memory formation.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.3390/ijms252212318" class="publication-link">
                Differential Dynamics and Roles of FKBP51 Isoforms and Their Implications for Targeted Therapies
            </a>
        </h3>
        <div class="publication-venue"><em>International Journal of Molecular Sciences</em> <strong>25</strong>(22), 12318</div>
        <div class="publication-authors"><strong>S Martinelli</strong>, K Hafner, M Koedel, J Knauer-Arloth, NC Gassen, EB Binder</div>
        <div class="publication-curiosity">🎭 Same gene, different masks — FKBP51's isoforms play opposing roles in stress and disease.</div>
        <div class="publication-description">Characterizes the differential dynamics and functional roles of FKBP51 protein isoforms, with implications for isoform-targeted therapeutic strategies.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                Interrogating the Spatial Biology of Pancreatic Cancer-Associated Fibroblasts
            </a>
        </h3>
        <div class="publication-venue"><em>Pancreas</em> <strong>53</strong>(10), E852</div>
        <div class="publication-authors">A Bryce, S Dreyer, F Froeling, <strong>S Martinelli</strong>, R Pennie, L Officer-Jones, ...</div>
        <div class="publication-curiosity">🗺️ Mapping the tumor's support network one fibroblast at a time.</div>
        <div class="publication-description">Conference abstract exploring the spatial biology of cancer-associated fibroblasts in pancreatic cancer.</div>
    </div>
</div>

## 2023

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1007/s00401-023-02541-9" class="publication-link">
                Associations of Psychiatric Disease and Ageing With FKBP5 Expression Converge on Superficial Layer Neurons of the Neocortex
            </a>
        </h3>
        <div class="publication-venue"><em>Acta Neuropathologica</em> <strong>145</strong>(4), 439–459</div>
        <div class="publication-authors">N Matosin, J Arloth, D Czamara, KZ Edmond, M Maitra, AS Fröhlich, ...</div>
        <div class="publication-curiosity">� Aging and mental illness leave the same molecular fingerprint on the brain's outermost neurons.</div>
        <div class="publication-description">Reveals that FKBP5 expression changes associated with psychiatric disease and aging converge on superficial layer neurons of the neocortex.</div>
    </div>
</div>

## 2022

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1176/appi.ajp.2021.21010095" class="publication-link">
                Cell-Type-Specific Impact of Glucocorticoid Receptor Activation on the Developing Brain: A Cerebral Organoid Study
            </a>
        </h3>
        <div class="publication-venue"><em>American Journal of Psychiatry</em> <strong>179</strong>(5), 375–387</div>
        <div class="publication-authors">C Cruceanu, L Dony, AC Krontira, DS Fischer, S Roeh, R Di Giaimo, ...</div>
        <div class="publication-curiosity">� Mini-brains grown in a dish can reveal how prenatal stress rewires the developing mind.</div>
        <div class="publication-description">Uses cerebral organoids to study cell-type-specific effects of glucocorticoid receptor activation on the developing brain, linking prenatal stress to psychiatric vulnerability.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1016/j.celrep.2022.111766" class="publication-link">
                Hippo-Released WWC1 Facilitates AMPA Receptor Regulatory Complexes for Hippocampal Learning
            </a>
        </h3>
        <div class="publication-venue"><em>Cell Reports</em> <strong>41</strong>(10)</div>
        <div class="publication-authors">J Stepan, DE Heinz, F Dethloff, T Bajaj, A Zellner, K Hafner, S Wiechmann, ...</div>
        <div class="publication-curiosity">📚 A growth-control pathway moonlights as a molecular architect of learning and memory.</div>
        <div class="publication-description">Demonstrates that Hippo pathway-released WWC1 facilitates AMPA receptor regulatory complexes essential for hippocampal learning processes.</div>
    </div>
</div>

## 2021

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1038/s41467-021-24810-5" class="publication-link">
                Stress-Primed Secretory Autophagy Promotes Extracellular BDNF Maturation by Enhancing MMP9 Secretion
            </a>
        </h3>
        <div class="publication-venue"><em>Nature Communications</em> <strong>12</strong>(1), 4643</div>
        <div class="publication-authors"><strong>S Martinelli</strong>, EA Anderzhanova, T Bajaj, S Wiechmann, F Dethloff, ...</div>
        <div class="publication-curiosity">🧹 Stress teaches cells to take out the trash — and in doing so, matures a key brain growth factor.</div>
        <div class="publication-description">Reveals how stress-primed secretory autophagy promotes extracellular BDNF maturation through enhanced MMP9 secretion, connecting stress biology to neurotrophic signaling.</div>
    </div>
</div>

## 2020

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                DNA Methylation, Gene and Protein Expression of FKBP5 in the Human Cortex Over the Life Course and in Severe Psychopathology
            </a>
        </h3>
        <div class="publication-venue"><em>Neuropsychopharmacology</em> <strong>45</strong>(Suppl 1), 105</div>
        <div class="publication-authors">N Matosin, <strong>S Martinelli</strong>, D Czamara, D Kaul, N Gassen, K Hafner, ...</div>
        <div class="publication-curiosity">🧬 Your DNA doesn't change with age — but the marks on it do, and they tell the story of a lifetime of stress.</div>
        <div class="publication-description">Examines DNA methylation, gene and protein expression of FKBP5 across the human cortex over the lifespan and in severe psychopathology.</div>
    </div>
</div>

## 2019

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1038/s41467-019-13659-4" class="publication-link">
                SKP2 Attenuates Autophagy Through Beclin1-Ubiquitination and Its Inhibition Reduces MERS-Coronavirus Infection
            </a>
        </h3>
        <div class="publication-venue"><em>Nature Communications</em> <strong>10</strong>(1), 5770</div>
        <div class="publication-authors">NC Gassen, D Niemeyer, D Muth, VM Corman, <strong>S Martinelli</strong>, A Gassen, ...</div>
        <div class="publication-curiosity">🦠 Coronaviruses hijack the cell's cleanup crew — blocking the hijacker stops the infection.</div>
        <div class="publication-description">Shows that SKP2-mediated Beclin1 ubiquitination attenuates autophagy, and that SKP2 inhibition reduces MERS-Coronavirus infection — linking autophagy regulation to antiviral defense.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://doi.org/10.1073/pnas.1816847116" class="publication-link">
                Epigenetic Upregulation of FKBP5 by Aging and Stress Contributes to NF-κB–Driven Inflammation and Cardiovascular Risk
            </a>
        </h3>
        <div class="publication-venue"><em>Proceedings of the National Academy of Sciences</em> <strong>116</strong>(23), 11370–11379</div>
        <div class="publication-authors">AS Zannas, M Jia, K Hafner, J Baumert, T Wiechmann, JC Pape, J Arloth, ...</div>
        <div class="publication-curiosity">❤️‍🔥 Stress literally gets under your skin — aging and trauma leave epigenetic scars that inflame the heart.</div>
        <div class="publication-description">Demonstrates that epigenetic derepression of FKBP5 by aging and stress drives NF-κB–mediated inflammation and increases cardiovascular disease risk.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://edoc.ub.uni-muenchen.de/25423/" class="publication-link">
                Effect of Stress on Protein Homeostasis Mediated by FKBP51 as a Possible Mechanism Underlying Stress-Related Disorders
            </a>
        </h3>
        <div class="publication-venue"><em>PhD Thesis</em>, Ludwig-Maximilians-Universität München</div>
        <div class="publication-authors"><strong>S Martinelli</strong></div>
        <div class="publication-curiosity">🎓 "The purpose of research is insight, not just data."</div>
        <div class="publication-description">Doctoral dissertation investigating how stress impacts protein homeostasis through FKBP51, exploring mechanisms underlying stress-related psychiatric disorders.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                Unravelling the Differential Role of FKBP51 Isoforms in Different Cellular Pathways
            </a>
        </h3>
        <div class="publication-venue"><em>Elsevier</em></div>
        <div class="publication-authors"><strong>S Martinelli</strong>, T Wiechmann, H Kathrin, L Meinhold, S Roeh, S Sauer, ...</div>
        <div class="publication-curiosity">🔀 One protein, many faces — each isoform takes a different path through the cell.</div>
        <div class="publication-description">Explores the distinct functional roles of FKBP51 isoforms across different cellular pathways.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                FKBP5 Gene Expression and DNA Methylation in Human Brain Over the Lifetime: Impact of Severe Psychopathology
            </a>
        </h3>
        <div class="publication-venue"><em>Neuropsychopharmacology</em> <strong>44</strong>(Suppl 1), 349</div>
        <div class="publication-authors">N Matosin, <strong>S Martinelli</strong>, D Czamara, N Gassen, T Wiechmann, K Hafner, ...</div>
        <div class="publication-curiosity">🧠 The brain's epigenetic clock ticks differently in those who suffer most.</div>
        <div class="publication-description">Examines FKBP5 gene expression and DNA methylation patterns in the human brain across the lifespan in the context of severe psychopathology.</div>
    </div>
</div>

## 2018

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                T180. Unraveling the Effect of Physiological Stress on Chaperone Mediated Autophagy-Dependent Synaptic Proteostasis
            </a>
        </h3>
        <div class="publication-venue"><em>Biological Psychiatry</em> <strong>83</strong>(9), S197–S198</div>
        <div class="publication-authors"><strong>S Martinelli</strong>, D Park, H Hafner, N Nagaraj, E Binder, NC Gassen</div>
        <div class="publication-curiosity">⚖️ Synapses need constant quality control — stress can tip the balance.</div>
        <div class="publication-description">Investigates the effects of physiological stress on chaperone-mediated autophagy and its role in synaptic proteostasis.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                Epigenetic Derepression of FKBP5 by Aging and Stress Contributes to NF-κB-Driven Inflammation and Cardiovascular Risk
            </a>
        </h3>
        <div class="publication-venue"><em>bioRxiv</em>, 484709</div>
        <div class="publication-authors">AS Zannas, M Jia, K Hafner, J Baumert, T Wiechmann, JC Pape, J Arloth, ...</div>
        <div class="publication-curiosity">📝 Science in progress — the preprint that became one of the most cited papers on stress epigenetics.</div>
        <div class="publication-description">Preprint version of the PNAS paper demonstrating epigenetic derepression of FKBP5 by aging and stress driving NF-κB–mediated inflammation.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                Investigation of Prenatal Stress in the Cerebral Organoid Model: A Focus on Cell-Type Specific Responses Following Glucocorticoid Exposure
            </a>
        </h3>
        <div class="publication-venue"><em>Biological Psychiatry</em> <strong>83</strong>(9), S77</div>
        <div class="publication-authors">C Cruceanu, S Roeh, S Wehner, <strong>S Martinelli</strong>, M Koedel, R Di Giaimo, ...</div>
        <div class="publication-curiosity">🤰 What a mother experiences during pregnancy can reshape her baby's brain — cell by cell.</div>
        <div class="publication-description">Studies prenatal stress effects using cerebral organoids, focusing on cell-type specific responses to glucocorticoid exposure.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                The Postmortem Human Brain to Characterize Novel Drug Targets for Psychiatric Disorders: Using FKBP5 as an Example
            </a>
        </h3>
        <div class="publication-venue"><em>Biological Psychiatry</em> <strong>83</strong>(9), S28–S29</div>
        <div class="publication-authors">N Matosin, <strong>S Martinelli</strong>, C Cruceanu, G Turecki, E Binder</div>
        <div class="publication-curiosity">🔍 The dead can still teach the living — postmortem brains reveal new drug targets for the mind.</div>
        <div class="publication-description">Uses postmortem human brain tissue to characterize FKBP5 as a novel drug target for psychiatric disorders.</div>
    </div>
</div>

## 2017

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                La Tecnologia nel Cervello
            </a>
        </h3>
        <div class="publication-venue"><em>Scienza&amp;Società</em> 21/22. Mentecorpo: Il cervello non è una macchina, 109</div>
        <div class="publication-authors"><strong>S Martinelli</strong>, M Ventricelli</div>
        <div class="publication-curiosity">🇮🇹 Where neuroscience meets society — science communication in the mother tongue.</div>
        <div class="publication-description">Essay exploring the intersection of technology and brain science, published in the Italian science-and-society series.</div>
    </div>
</div>

<div class="publication-card">
    <div class="publication-content">
        <h3 class="publication-title">
            <a href="https://scholar.google.com/citations?user=Fc0Qo4kAAAAJ&hl=en" class="publication-link">
                Explication of FKBP5 Methylation and Transcription Patterns in Postmortem Human Cortex
            </a>
        </h3>
        <div class="publication-venue"><em>56th Annual Meeting of the American College of Neuropsychopharmacology (ACNP)</em></div>
        <div class="publication-authors">N Matosin, <strong>S Martinelli</strong>, Y Awaloff, T Wiechmann, A Schmitt, T Arzberger, ...</div>
        <div class="publication-curiosity">🧪 Epigenetic marks in the cortex whisper the molecular history of psychiatric illness.</div>
        <div class="publication-description">Characterizes FKBP5 methylation and transcription patterns in postmortem human cortex, informing epigenetic mechanisms in psychiatric disease.</div>
    </div>
</div>
