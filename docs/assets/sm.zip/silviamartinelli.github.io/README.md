# Silvia Martinelli

Personal website & publications portfolio.

🔗 **Live:** [silviamartinelli.github.io](https://silviamartinelli.github.io)
